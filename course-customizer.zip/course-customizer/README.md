# Course customizer

The actual custom plugin that customizes the courses and does the other functionalities.
